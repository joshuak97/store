<style type="text/css">

table { vertical-align: top; }
tr    { vertical-align: top; }
td    { vertical-align: top; }
.midnight-blue{
	background:#2c3e50;
	padding: 4px 4px 4px;
	color:white;
	font-weight:bold;
	font-size:12px;
}
.silver{
	background:white;
	padding: 3px 4px 3px;
}
.clouds{
	background:#ecf0f1;
	padding: 3px 4px 3px;
}
.border-top{
	border-top: solid 1px #bdc3c7;
	
}
.border-left{
	border-left: solid 1px #bdc3c7;
}
.border-right{
	border-right: solid 1px #bdc3c7;
}
.border-bottom{
	border-bottom: solid 1px #bdc3c7;
}
table.page_footer {width: 100%; border: none; background-color: white; padding: 15mm;border-collapse:collapse; border: none;}
}
</style>
<page backtop="15mm" backbottom="15mm" backleft="15mm" backright="15mm" style="font-size: 12pt; font-family: arial" >
        
    <?php 
    $numero_factura=0;
	include("encabezado_factura.php");
	?>
   
    <br>
    <br>
	<br>
	
    <table cellspacing="0" style="width: 100%; text-align: left; font-size: 11pt;">
        <tr>
           <td style="width:50%;" class='midnight-blue'>CLIENTE:</td>
        </tr>
		<tr>
           <td style="width:50%;" >
			<?php 
				echo 'REFACCIONARIA PATIÑO';
			?>
			
		   </td>
        </tr>
        
   
    </table>
    
       <br>
		<table cellspacing="0" style="width: 100%; text-align: left; font-size: 11pt;">
        <tr>
           
		  <td style="width:30%;" class='midnight-blue'>FECHA DE COMPRA</td>
		  <td style="width:30%;" class='midnight-blue'>FECHA DE PAGO</td>
		   <td style="width:40%;" class='midnight-blue'>FORMA DE PAGO</td>
        </tr>
		<tr>
          
		  <td style="width:30%;"><?php echo $cuentaP['fecha_compra']?></td>
		  <td style="width:30%;"><?php echo $cuentaP['fecha_pago']?></td>
		   <td style="width:40%;" >
				<?php 
				echo $cuentaP['tipo_compra'];
			
				?>
		   </td>
        </tr>
		
        
   
    </table>
	<br>
  
    <table cellspacing="0" style="width: 100%; text-align: left; font-size: 10pt;">
        <tr>
            <th style="width: 10%;text-align:center" class='midnight-blue'>CANT.</th>
            <th style="width: 60%" class='midnight-blue'>DESCRIPCION</th>
            <th style="width: 15%;text-align: right" class='midnight-blue'>PRECIO UNIT.</th>
            <th style="width: 15%;text-align: right" class='midnight-blue'>PRECIO TOTAL</th>
            
        </tr>

<?php

$suma=0;
$_SESSION['contador2']=0;
$prod=explode(" ", $idProd);

for($i=0;$i<count($prod);$i++){
$prod2=explode(",",$prod[$i]);

//$consulta2=ejecutarSQL::consultar("SELECT * FROM producto where idProd=".$prod2[0]);
//while($fila2= mysqli_fetch_array($consulta2)) {
	
$_SESSION['productos2'][$i]=$prod2[0];
$_SESSION['cantidad2'][$i]=$prod2[1];
//$suma += $fila2['precioVenta']*$prod2[1];
$_SESSION['contador2']++;
  //  }
}


$nums=1;
$sumador_total=0;

for($u=0;$u<$_SESSION['contador2'];$u++){
if($_SESSION['productos2'][$u]!=""){

$prods=mysqli_query($con, "select * from producto where idProd=".$_SESSION['productos2'][$u]);
while ($row=mysqli_fetch_array($prods))
	{
	
	$id_producto=$row["idProd"];
	$codigo_producto=$row['codProd'];
	$cantidad=$_SESSION['cantidad2'][$u];
	$nombre_producto=$row['nombreProd'];	
	$precio_venta=$row['precioCosto'];
	$precio_venta_f=number_format($precio_venta,2);//Formateo variables
	$precio_venta_r=str_replace(",","",$precio_venta_f);//Reemplazo las comas
	$precio_total=$precio_venta_r*$cantidad;
	$precio_total_f=number_format($precio_total,2);//Precio total formateado
	$precio_total_r=str_replace(",","",$precio_total_f);//Reemplazo las comas
	
	
	}	
	if ($nums%2==0){
		$clase="clouds";
	} else {
		$clase="silver";
	}



	?>

        <tr>
            <td class='<?php echo $clase;?>' style="width: 10%; text-align: center"><?php echo $cantidad; ?></td>
            <td class='<?php echo $clase;?>' style="width: 60%; text-align: left"><?php echo $nombre_producto;?></td>
            <td class='<?php echo $clase;?>' style="width: 15%; text-align: right"><?php echo $precio_venta_f;?></td>
            <td class='<?php echo $clase;?>' style="width: 15%; text-align: right"><?php echo $precio_total_f;?></td>
            
        </tr>

	<?php 
	//Insert en la tabla detalle_cotizacion
	
	$nums++;
	}

}
	$impuesto=13;
	$subtotal=number_format($cuentaP['costoCompra'],2,'.','');
	
?>
	  
        <tr>
            <td colspan="3" style="width: 85%; text-align: right;">TOTAL $ </td>
            <td style="width: 15%; text-align: right;"> <?php echo number_format($subtotal,2);?></td>
        </tr>
		          
    </table>
	
	
	
	<br>
	<!--<div style="font-size:11pt;text-align:center;font-weight:bold">Gracias por su compra!</div>-->
	
	<page_footer>
        <table class="page_footer">
            <tr>

                <td style="width: 50%; text-align: left">
                    P&aacute;gina [[page_cu]]/[[page_nb]]
                </td>
                <td style="width: 50%; text-align: right">
                    &copy; <?php echo "EworkSolutions"; echo  $anio=date('Y'); ?>
                </td>
            </tr>
        </table>
    </page_footer>
	  

</page>
